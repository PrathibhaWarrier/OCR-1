from django.shortcuts import render
from django.http import JsonResponse
from app.models import capacity, CapacityPlanning
from rest_framework import generics
# from app.serializers import YourModelSerializer
# Create your views here.
def index(request):
    data = CapacityPlanning.objects.all()
    return render(request, 'index.html', {'data':data})

def display_table(request):
    data = CapacityPlanning.objects.all()
    return render(request, 'index.html', {'data':data})

def get_data(request):
    data = CapacityPlanning.objects.all()
    return JsonResponse(list(data), safe=False)

# class YourModelListAPIView(generics.ListCreateAPIView):
#     queryset= capacity.objects.all()
#     serializer_class= YourModelSerializer

# class YourModelDetailAPIView(generics.ListCreateAPIView):
#     queryset= capacity.objects.all()
#     serializer_class= YourModelSerializer

 