from django.db import models

# Create your models here.
class capacity(models.Model):
    Plant= models.CharField(max_length=100)
    Phase= models.CharField(max_length=100)
    Process= models.CharField(max_length=100)
    Line = models.CharField(max_length=100)
    CostCenter= models.CharField(max_length=100)
    LineSpeed= models.CharField(max_length=100)
    Capacity= models.CharField(max_length=100)	
    WorkCenter= models.CharField(max_length=100)
    Technology= models.CharField(max_length=100)
    def __str__(self):
        return self.Plant

class CapacityPlanning(models.Model):
    Plant= models.CharField(max_length=100)
    Phase= models.CharField(max_length=100)
    Process= models.CharField(max_length=100)
    Line = models.CharField(max_length=100)
    CostCenter= models.CharField(max_length=100)
    CT= models.CharField(max_length=100)
    Capacity= models.CharField(max_length=100)	
    WorkCenter= models.CharField(max_length=100)
    Equipment= models.CharField(max_length=100)	
    EQID= models.CharField(max_length=100)
    Technology= models.CharField(max_length=100)
    MainValving= models.CharField(max_length=100)
    Rod= models.CharField(max_length=100)
    PT= models.CharField(max_length=100) 

    def __str__(self):
        return self.Plant

class SaleforceData(models.Model):
    Driv_Plant= models.CharField(max_length=100)
    GLobalAccount= models.CharField(max_length=100)
    PlatformText= models.CharField(max_length=100)
    ProgramText= models.CharField(max_length=100)
    MountingLocation= models.CharField(max_length=100)
    Technology= models.CharField(max_length=100)
    MainValving= models.CharField(max_length=100)
    Rod= models.CharField(max_length=100)
    PT= models.CharField(max_length=100)	
    CostCenter= models.CharField(max_length=100)
    ProgramClassification= models.CharField(max_length=100)
    UniqueCode= models.CharField(max_length=100)


    def __str__(self):
        return self.PlatformText
    
# class ClassificationData(models.Model):
#     D_Type= models.CharField(max_length=100)	
#     D_ID= models.CharField(max_length=100)	
#     MV_Type= models.CharField(max_length=100)	
#     MV_ID= models.CharField(max_length=100)	
#     Mtg_Loc= models.CharField(max_length=100)	
#     ML_ID= models.CharField(max_length=100)	
#     Customer= models.CharField(max_length=100)	
#     Platform= models.CharField(max_length=100)	
#     Customer_n_Platform= models.CharField(max_length=100)	
#     ID= models.CharField(max_length=100)	
#     Plant= models.CharField(max_length=100)	
#     PlantDesignation= models.CharField(max_length=100)

#     def __str__(self):
#         return self.D_Type

