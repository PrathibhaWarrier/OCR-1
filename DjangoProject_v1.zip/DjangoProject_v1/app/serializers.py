from rest_framework import serializers
from app.models import capacity, CapacityPlanning

class CapacitySerializer(serializers.ModelSerializer):
    class Meta:
        model=CapacityPlanning
        fields= '__all__'
        